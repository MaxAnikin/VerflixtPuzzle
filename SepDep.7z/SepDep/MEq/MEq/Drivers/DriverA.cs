﻿namespace Drivers
{
    public class DriverA : IDriverA
    {
        public string GetData()
        {
            return "DriverA";
        }
    }
}

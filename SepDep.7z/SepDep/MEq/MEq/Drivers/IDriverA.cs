﻿namespace Drivers;

public interface IDriverA
{
    string GetData();
}